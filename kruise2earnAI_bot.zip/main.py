# Entry point for kruise2earnAI bot
print('Bot running...')